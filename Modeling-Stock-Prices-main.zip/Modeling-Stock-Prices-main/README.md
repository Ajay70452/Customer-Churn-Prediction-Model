Modelling stock prices in the portfolio using multi-dimensional Brownian Motion


To run the code
1)Make sure your system has python3,numpy and matplotlib installed
2)To run the program open your terminal in the appropriate library and type the below command in the command line
"python3 GBM.py"

To change the parametrs
1)To change the values of mu and sigma, change the values in line 33 and 34
2)To change the correlation matrix please change the parameters at line 41
